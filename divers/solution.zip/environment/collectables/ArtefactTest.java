package environment.collectables;

import org.junit.jupiter.api.*;

public class ArtefactTest {

    @Test
    public void testSampleConstructor() {}
        
    @Test
    public void testRetrieve(){}

    @Test
    public void testTag() {}

    @Test 
    public void testText() {}

    @Test
    public void testSampleEquals() {}
}