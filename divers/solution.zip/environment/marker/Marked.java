package environment.marker;

public interface Marked {
    void tag();
}
