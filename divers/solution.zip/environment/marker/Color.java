package environment.marker;

public enum Color {
    RED, 
    GREEN, 
    BLUE;
}