package person.util;

public class WrongArtefact extends Exception {

    public WrongArtefact(String message) {
        super(message);
    }
}