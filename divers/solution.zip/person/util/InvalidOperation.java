package person.util;

public class InvalidOperation extends Exception {
    
}